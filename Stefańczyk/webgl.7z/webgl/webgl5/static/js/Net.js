class Net{
    constructor(){
        // document.getElementById("loguj").addEventListener("click",function(){
        //     console.log(window.val);
        // });
    }
    zaloguj(){
        console.log("zalogowano");
    }
}
