let user

class Ui{
    constructor(){
        document.getElementById("loguj").addEventListener("click",this.zaloguj)
        document.getElementById("reset").addEventListener("click",this.reset)
    }
    zaloguj(){
        user = {login:document.getElementById("login").value}
        console.log(user);
        const options = {
            method: "POST",
            headers: {
                "Accept":"application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify(user)
        };
        fetch("/zaloguj", options)
        .then(function(response){return response.json()})
        .then(function (data) { console.log(data) })
        .catch(function (error) { console.log(error) });
    }
    reset(){
        fetch("/reset", {method:"POST"})
        .then(function(response){return response.json()})
        .then(function (data) {
            document.getElementById("status").innerHTML = data;
            window.setInterval(function(){
                document.getElementById("status").innerHTML = "STATUS";
            },3000)
        })
        .catch(function (error) { console.log(error) });
    }
}