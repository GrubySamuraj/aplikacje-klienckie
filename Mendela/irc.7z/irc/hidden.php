<?php
$dbname = "irc";
$host = "localhost";
$user = "root";
$passwd = "zaq1@WSX";
